from __future__ import annotations

from dataclasses import dataclass
from fcode import EntityType, Environment, Position, Team
from .types import Threat, ThreatKind

PASSABLE_BUILDINGS = frozenset({EntityType.CONVEYOR, EntityType.SPLITTER})


@dataclass(frozen=True, slots=True)
class DynamicObservation:
    entity_type: EntityType; team: Team | None; seen_round: int; blocks: bool


class WorldMemory:
    __slots__ = ("width", "height", "static_walls", "ore_positions", "dynamic", "own_core", "enemy_core", "core_footprint", "threats", "obstacle_epoch", "goal", "goal_invalidated", "last_round")

    def __init__(self, width: int, height: int) -> None:
        self.width, self.height = max(0, int(width)), max(0, int(height)); self.static_walls=set(); self.ore_positions=set(); self.dynamic={}; self.own_core=None; self.enemy_core=None; self.core_footprint=set(); self.threats={}; self.obstacle_epoch=0; self.goal=None; self.goal_invalidated=False; self.last_round=0

    def _in_bounds(self, pos: Position) -> bool: return 0 <= pos.x < self.width and 0 <= pos.y < self.height
    def _core_cells(self, anchor: Position) -> set[Position]: return {cell for cell in (anchor, Position(anchor.x+1, anchor.y), Position(anchor.x, anchor.y+1), Position(anchor.x+1, anchor.y+1)) if self._in_bounds(cell)}

    def _set_dynamic(self, pos: Position, observation: DynamicObservation) -> None:
        old = self.dynamic.get(pos); self.dynamic[pos] = observation
        if old is None or old.blocks != observation.blocks: self.obstacle_epoch += 1
        if self.goal == pos and observation.blocks: self.goal_invalidated = True

    def _remove_dynamic(self, pos: Position) -> None:
        old = self.dynamic.pop(pos, None)
        if old is not None and old.blocks: self.obstacle_epoch += 1
        if old is not None and self.goal == pos: self.goal_invalidated = True

    def observe(self, ct: object, round_no: int | None = None) -> None:
        try: current = int(ct.get_current_round() if round_no is None else round_no)
        except Exception: current = self.last_round
        self.last_round = current
        try: tiles = tuple(ct.get_nearby_tiles())
        except Exception: tiles = ()
        try: own_team = ct.get_team()
        except Exception: own_team = None
        try: own_id = int(ct.get_id())
        except Exception: own_id = None
        for pos in tiles:
            if not self._in_bounds(pos): continue
            try: environment = ct.get_tile_env(pos)
            except Exception: continue
            if environment == Environment.WALL: self.static_walls.add(pos); continue
            if environment == Environment.ORE_TITANIUM: self.ore_positions.add(pos)
            try: building_id, builder_id = ct.get_tile_building_id(pos), ct.get_tile_builder_bot_id(pos)
            except Exception: building_id, builder_id = None, None
            entity_id = building_id if building_id is not None else builder_id
            if entity_id is None: self._remove_dynamic(pos); continue
            if entity_id == own_id:
                self._remove_dynamic(pos)
                continue
            try: entity_type = ct.get_entity_type(entity_id)
            except Exception: continue
            try: team = ct.get_team(entity_id)
            except Exception: team = None
            self._set_dynamic(pos, DynamicObservation(entity_type, team, current, entity_type not in PASSABLE_BUILDINGS))
            if entity_type == EntityType.CORE:
                if team == own_team: self.own_core = min((self.own_core, pos), key=lambda p: (p.y, p.x)) if self.own_core else pos; self.core_footprint.update(self._core_cells(self.own_core))
                elif team is not None: self.enemy_core = pos
            elif team is not None and own_team is not None and team != own_team:
                kind = ThreatKind.BUILDER_RUSH if entity_type == EntityType.BUILDER_BOT else ThreatKind.SABOTAGE
                self.threats[pos] = Threat(pos, kind, 4 if entity_type == EntityType.BUILDER_BOT else 2, current, current + 3, entity_type)
        self.expire_dynamic(current)
        for pos in tuple(self.threats):
            if self.threats[pos].expires_round <= current: self.threats.pop(pos)

    def expire_dynamic(self, current_round: int | None = None) -> None:
        current = self.last_round if current_round is None else int(current_round)
        for pos, observation in tuple(self.dynamic.items()):
            if current - observation.seen_round >= 3: self._remove_dynamic(pos)

    def classify(self, pos: Position) -> EntityType | Environment | None:
        if pos in self.static_walls: return Environment.WALL
        observation = self.dynamic.get(pos); return observation.entity_type if observation else None

    def is_blocked(self, pos: Position) -> bool:
        if not self._in_bounds(pos) or pos in self.static_walls or pos in self.core_footprint: return True
        observation = self.dynamic.get(pos); return observation.blocks if observation else False

    def is_passable(self, pos: Position) -> bool: return not self.is_blocked(pos)
    def set_goal(self, goal: Position | None) -> None: self.goal, self.goal_invalidated = goal, False

    def consume_goal_invalidation(self) -> bool:
        result = self.goal_invalidated; self.goal_invalidated = False; return result

    def invalidate_after_throw(self, position: Position | None = None) -> None:
        if position is not None: self.dynamic.pop(position, None)
        self.obstacle_epoch += 1; self.goal_invalidated = True

    def known_ore(self) -> tuple[Position, ...]: return tuple(sorted(self.ore_positions, key=lambda pos: (pos.y, pos.x)))

    def threat_list(self, current_round: int | None = None) -> tuple[Threat, ...]:
        current = self.last_round if current_round is None else current_round
        return tuple(sorted((threat for threat in self.threats.values() if threat.expires_round > current), key=lambda threat: (-threat.score, threat.position.y, threat.position.x)))
