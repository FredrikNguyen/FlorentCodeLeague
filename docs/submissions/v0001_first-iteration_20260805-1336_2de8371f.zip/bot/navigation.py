from __future__ import annotations

from collections import deque
from typing import Callable
from fcode import Controller, Direction, Position
from .actions import TurnActions

CARDINALS = (Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST)
def _inside(pos: Position, width: int, height: int) -> bool: return 0 <= pos.x < width and 0 <= pos.y < height


def bounded_bfs(start: Position, goal: Position, width: int, height: int, blocked: Callable[[Position], bool] | set[Position] | frozenset[Position] | None = None, *, max_expansions: int | None = None, cpu_check: Callable[[], bool] | None = None, stats: dict[str, int] | None = None) -> list[Position]:
    if stats is not None: stats["expansions"] = 0
    width, height = int(width), int(height)
    if width <= 0 or height <= 0 or not _inside(start, width, height) or not _inside(goal, width, height): return []

    area = width * height; start_index = start.y * width + start.x; goal_index = goal.y * width + goal.x; blocked_indices: set[int] | None = None; blocked_fn: Callable[[Position], bool] | None = None
    if isinstance(blocked, (set, frozenset)): blocked_indices = {position.y * width + position.x for position in blocked if _inside(position, width, height)}
    elif blocked is not None: blocked_fn = blocked

    def is_blocked(index: int, x: int, y: int) -> bool:
        if blocked_indices is not None: return index in blocked_indices
        if blocked_fn is None: return False
        try: return bool(blocked_fn(Position(x, y)))
        except Exception: return True

    if is_blocked(start_index, start.x, start.y) or is_blocked(goal_index, goal.x, goal.y): return []
    if start_index == goal_index: return [start]

    limit = min(area, max(1, area if max_expansions is None else int(max_expansions))); parents = [-2] * area; parents[start_index] = -1; queue = deque((start_index,)); expansions = 0; found = False; neighbours = ((0, -1, -width), (1, 0, 1), (0, 1, width), (-1, 0, -1))
    while queue and expansions < limit:
        if cpu_check is not None:
            try: value = cpu_check(); safe = value if isinstance(value, bool) else int(value) < 7000
            except Exception: safe = False
            if not safe: break
        current = queue.popleft(); expansions += 1; x, y = current % width, current // width
        for dx, dy, delta in neighbours:
            nx, ny = x + dx, y + dy
            if nx < 0 or nx >= width or ny < 0 or ny >= height: continue
            neighbour = current + delta
            if parents[neighbour] != -2 or is_blocked(neighbour, nx, ny): continue
            parents[neighbour] = current
            if neighbour == goal_index: found = True; break
            queue.append(neighbour)
        if found: break

    if stats is not None: stats["expansions"] = expansions
    if parents[goal_index] == -2: return []
    path: list[Position] = []; cursor = goal_index
    while cursor >= 0: path.append(Position(cursor % width, cursor // width)); cursor = parents[cursor]
    path.reverse()
    return path


class PathCache:
    __slots__ = ("_paths", "_limit", "hits", "misses")
    def __init__(self, limit: int = 12) -> None: self._paths, self._limit, self.hits, self.misses = {}, max(1, int(limit)), 0, 0
    def get(self, key):
        path = self._paths.get(key); self.hits += path is not None; self.misses += path is None; return path
    def put(self, key, path):
        if len(self._paths) >= self._limit and key not in self._paths: self._paths.pop(next(iter(self._paths)))
        self._paths[key] = tuple(path)
    def invalidate(self, key=None): self._paths.clear() if key is None else self._paths.pop(key, None)
    def clear(self): self._paths.clear()
    def __len__(self): return len(self._paths)


class Navigator:
    __slots__ = ("width", "height", "blocked", "cpu", "cache", "history", "fallback_cursor", "last_key", "replans")
    def __init__(self, width: int, height: int, blocked=None, *, cpu: Callable[[], int] | None = None, cache_limit: int = 12) -> None:
        self.width, self.height, self.blocked, self.cpu = max(0, int(width)), max(0, int(height)), blocked, cpu; self.cache=PathCache(cache_limit); self.history=deque(maxlen=4); self.fallback_cursor=0; self.last_key=None; self.replans=0
    def _is_blocked(self, pos):
        try:
            return (pos in self.blocked) if self.blocked is not None and not callable(self.blocked) else bool(self.blocked(pos)) if self.blocked is not None else False
        except Exception: return True
    def _safe(self):
        try: return self.cpu is None or int(self.cpu()) < 7000
        except Exception: return False
    def _greedy(self, start, goal, can_step):
        preferred = start.cardinal_direction_to(goal); ordered = (preferred,) + tuple(direction for direction in CARDINALS if direction != preferred)
        for direction in ordered:
            candidate = start.add(direction)
            if direction == Direction.CENTRE or not _inside(candidate, self.width, self.height) or self._is_blocked(candidate): continue
            try: legal = can_step is None or bool(can_step(direction))
            except Exception: legal = False
            if legal: return direction
        return Direction.CENTRE
    def _record(self, position):
        result = len(self.history) == 4 and position in self.history; self.history.append(position); return result
    def invalidate(self): self.cache.clear(); self.last_key = None
    def next_direction(self, start: Position, goal: Position, obstacle_epoch: int = 0, *, can_step: Callable[[Direction], bool] | None = None) -> Direction:
        if start == goal: self.history.clear(); self.history.append(start); return Direction.CENTRE
        key, oscillating = (start, goal, int(obstacle_epoch)), self._record(start)
        safe = self._safe()
        path = None if oscillating or not safe else self.cache.get(key)
        if path is None and safe:
            path = tuple(bounded_bfs(start, goal, self.width, self.height, self.blocked, max_expansions=self.width * self.height, cpu_check=self._safe if self.cpu is not None else None))
            self.replans += 1
            if path:
                self.cache.put(key, path)
        self.last_key = key
        if path and len(path) > 1:
            step, direction = path[1], start.cardinal_direction_to(path[1])
            try: legal = can_step is None or bool(can_step(direction))
            except Exception: legal = False
            if not self._is_blocked(step) and legal: return direction
            self.cache.invalidate(key); self.replans += 1
        return self._greedy(start, goal, can_step)


def move_toward_or_fallback(ct: Controller, target: Position, *, cursor: int, actions: TurnActions | None = None) -> tuple[bool, int]:
    turn = actions or TurnActions(ct); preferred = ct.get_position().cardinal_direction_to(target); directions = ((preferred,) if preferred != Direction.CENTRE else ()) + CARDINALS
    for offset, direction in enumerate(directions):
        if direction in directions[:offset]: continue
        if turn.move(direction): return True, (cursor + offset + 1) % 4
    return False, (cursor + 1) % 4
