from __future__ import annotations

from enum import IntEnum
from fcode import Position
from .types import Budget, Claim, Opening, Phase, Threat, ThreatKind


class Slot(IntEnum):
    SCHEMA_VERSION = 0; STRATEGY = 1; PRIMARY_ORE = 2; ENEMY_CORE = 3; THREAT = 4; LOGISTICS = 5; DESIRED_BUILDERS = 6; AMMO_TARGET = 7; DEFENSE_ALERT = 8; RALLY = 9; CLAIM_0 = 10; CLAIM_1 = 11; CLAIM_2 = 12; BUDGET = 13; RESERVED = 14; EPOCH = 15


SCHEMA_VERSION = 2; UNKNOWN = 0; COORD_BITS = 10; EPOCH_BITS = 6; OWNER_BITS = 16; COORD_MASK = 1023; EPOCH_MASK = 63; OWNER_MASK = 65535; MAX_U32 = 0xFFFFFFFF
CORE_SLOTS = frozenset({Slot.SCHEMA_VERSION, Slot.STRATEGY, Slot.DESIRED_BUILDERS, Slot.AMMO_TARGET, Slot.EPOCH})
CLAIM_OWNER_SLOTS = {0: frozenset({Slot.PRIMARY_ORE, Slot.ENEMY_CORE, Slot.RALLY, Slot.CLAIM_0}), 1: frozenset({Slot.LOGISTICS, Slot.CLAIM_1, Slot.DEFENSE_ALERT}), 2: frozenset({Slot.THREAT, Slot.BUDGET, Slot.CLAIM_2})}
SLOT_OWNER = {slot: "core" for slot in CORE_SLOTS}
for _owner, _slots in CLAIM_OWNER_SLOTS.items():
    for _slot in _slots: SLOT_OWNER[_slot] = _owner
SLOT_OWNER[Slot.RESERVED] = None


def _valid(pos: Position, width: int, height: int | None = None) -> bool:
    return width > 0 and pos.x >= 0 and pos.y >= 0 and pos.x < width and (height is None or pos.y < height)


def pack_position(pos: Position, width: int, height: int | None = None) -> int:
    if not _valid(pos, width, height): raise ValueError("position outside map")
    value = 1 + pos.y * width + pos.x
    if value > COORD_MASK: raise ValueError("position does not fit ten-bit coordinate")
    return value


def unpack_position(value: int, width: int, height: int | None = None) -> Position | None:
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= COORD_MASK or width <= 0: return None
    position = Position((value - 1) % width, (value - 1) // width)
    return position if _valid(position, width, height) else None


def pack_epoch(epoch: int) -> int:
    if isinstance(epoch, bool) or not isinstance(epoch, int): raise ValueError("epoch must be an integer")
    return epoch & EPOCH_MASK


def epoch_distance(now: int, then: int) -> int: return (int(now) - int(then)) & EPOCH_MASK
def claim_is_fresh(claim: Claim | None, now_epoch: int) -> bool: return claim is not None and claim.owner_id > 0 and epoch_distance(now_epoch, claim.epoch) <= 31


def pack_claim(position: Position | None, width: int, epoch: int, owner_id: int, height: int | None = None) -> int:
    if isinstance(owner_id, bool) or not isinstance(owner_id, int) or not 0 <= owner_id <= OWNER_MASK: raise ValueError("owner id does not fit codec")
    coordinate = 0 if position is None else pack_position(position, width, height)
    return (coordinate << 22) | (pack_epoch(epoch) << 16) | owner_id


def unpack_claim(value: int, width: int, height: int | None = None) -> Claim | None:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 < value <= MAX_U32: return None
    coordinate, epoch, owner = (value >> 22) & COORD_MASK, (value >> 16) & EPOCH_MASK, value & OWNER_MASK
    if owner == 0: return None
    position = None if coordinate == 0 else unpack_position(coordinate, width, height)
    return None if coordinate and position is None else Claim(position, epoch, owner)


def claim_slot(owner_index: int) -> Slot:
    if owner_index not in (0, 1, 2): raise ValueError("claim owner must be 0, 1, or 2")
    return Slot.CLAIM_0 + owner_index


def slot_owner(slot: int | Slot) -> str | int | None:
    try: return SLOT_OWNER.get(Slot(slot))
    except (TypeError, ValueError): return None


def can_write(slot: int | Slot, writer: str | int) -> bool: return (owner := slot_owner(slot)) is not None and owner == writer


def encode_strategy(phase: Phase, opening: Opening) -> int: return tuple(Phase).index(phase) | (tuple(Opening).index(opening) << 4)


def decode_strategy(value: int) -> tuple[Phase, Opening] | None:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0: return None
    try: return tuple(Phase)[value & 15], tuple(Opening)[(value >> 4) & 15]
    except IndexError: return None


def encode_threat(threat: Threat, width: int, height: int | None = None) -> int: return pack_position(threat.position, width, height) | (tuple(ThreatKind).index(threat.kind) << 10)


def decode_threat(value: int, width: int, height: int | None = None) -> Threat | None:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 < value <= MAX_U32: return None
    position, kind = unpack_position(value & COORD_MASK, width, height), (value >> 10) & 15
    return None if position is None or kind >= len(tuple(ThreatKind)) else Threat(position, tuple(ThreatKind)[kind])


def encode_budget(budget: Budget) -> int:
    encoded = 0
    for index, value in enumerate((budget.construction, budget.defense, budget.ammo, budget.expansion, budget.liquidity)): encoded |= max(0, min(63, int(value // 10))) << index * 6
    return encoded


def decode_budget(value: int) -> Budget | None:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= MAX_U32: return None
    return Budget(*(((value >> index * 6) & 63) * 10 for index in range(5)))


def encode_alert(position: Position | None, width: int, expires_epoch: int = 0) -> int: return (0 if position is None else pack_position(position, width)) | ((expires_epoch & EPOCH_MASK) << 10)


def decode_alert(value: int, width: int, height: int | None = None) -> tuple[Position | None, int] | None:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= MAX_U32: return None
    coordinate, position = value & COORD_MASK, None
    if coordinate: position = unpack_position(coordinate, width, height)
    return None if coordinate and position is None else (position, (value >> 10) & EPOCH_MASK)

