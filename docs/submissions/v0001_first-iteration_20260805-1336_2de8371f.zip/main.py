"""Florent Code League submission entry point."""

from bot.player import Player

__all__ = ["Player"]
