# Candidate bot instructions

These instructions apply to all files under `bots/candidate/`.

## Required reading before editing

1. Read the root `AGENTS.md` and `docs/START_HERE.md`.
2. Read `GAME_RULES.md` and the relevant section of `docs/IMPLEMENTATION_PLAN.md`.
3. Read the current experiment record, if one is named in `state/project_state.json`.
4. For performance or promotion claims, read `docs/EVALUATION_PLAN.md`.

## Scope and packaging

- This directory is the only mutable bot implementation.
- It must remain a self-contained, pure-Python submission with `main.py` exporting `Player`.
- Do not import files from repository directories outside `bots/candidate/`.
- Do not add native extensions, runtime package installation, network access, or external filesystem dependencies.
- Never edit `bots/baseline/` as part of a candidate experiment.

## Runtime correctness

- Route by `ct.get_entity_type()` and preserve per-unit instance state.
- Gate every action with the matching `can_*` method.
- Builder movement is cardinal only; use `cardinal_direction_to`, never unrestricted `direction_to` for movement.
- Build, attack, heal, and destroy only orthogonally adjacent targets.
- A Builder cannot move and act in the same round.
- Do not let exceptions escape `run()`.
- Query current costs through Controller getters.
- Respect one-round-delayed Global Store writes and named single-writer ownership.
- Keep per-turn work bounded and target p99 below 8 ms under `--tle 10`.
- Preserve deterministic behavior for a fixed seed unless randomness is the explicit experiment.

## Strategy and state-machine discipline

- One hypothesis per change.
- Verify world state before advancing a state machine.
- Expire or invalidate stale dynamic observations.
- Avoid duplicate claims and multi-Builder pileups.
- Measure delivered titanium rather than structure count.
- Separate mechanism changes from policy changes when possible.
- Keep a safe fallback when a target, path, route, or budget becomes invalid.

## Completion gate

At minimum, run:

```bash
make static
make smoke
```

For a candidate intended for promotion, also run the applicable regression, full local, and remote gates from `docs/EVALUATION_PLAN.md`. Save evidence under `reports/`, update the experiment record, and let the root orchestration workflow update `UPDATES.md` and startup state.
