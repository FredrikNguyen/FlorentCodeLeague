"""Small deterministic navigation helpers.

The initial candidate intentionally uses a cheap fallback. Replace it with the bounded
cached BFS described in docs/IMPLEMENTATION_PLAN.md through an evaluated experiment.
"""

from __future__ import annotations

from fcode import Controller, Direction, Position


CARDINALS = (
    Direction.NORTH,
    Direction.EAST,
    Direction.SOUTH,
    Direction.WEST,
)


def move_toward_or_fallback(
    ct: Controller,
    target: Position,
    *,
    cursor: int,
) -> tuple[bool, int]:
    """Attempt a cardinal step toward target, then deterministic alternatives."""
    preferred = ct.get_position().cardinal_direction_to(target)
    if preferred != Direction.CENTRE and ct.can_move(preferred):
        ct.move(preferred)
        return True, cursor

    for offset in range(len(CARDINALS)):
        direction = CARDINALS[(cursor + offset) % len(CARDINALS)]
        if ct.can_move(direction):
            ct.move(direction)
            return True, (cursor + offset + 1) % len(CARDINALS)

    return False, (cursor + 1) % len(CARDINALS)
