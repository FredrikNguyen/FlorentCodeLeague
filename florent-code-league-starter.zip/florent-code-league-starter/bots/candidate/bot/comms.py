"""Versioned helpers for the 16-slot, one-round-delayed team store."""

from __future__ import annotations

from enum import IntEnum

from fcode import Position


class Slot(IntEnum):
    SCHEMA_VERSION = 0
    STRATEGY = 1
    PRIMARY_ORE = 2
    ENEMY_CORE = 3
    THREAT = 4
    LOGISTICS = 5
    DESIRED_BUILDERS = 6
    AMMO_TARGET = 7
    DEFENSE_ALERT = 8
    RALLY = 9


SCHEMA_VERSION = 1
UNKNOWN = 0


def pack_position(pos: Position, width: int) -> int:
    """Encode every in-bounds coordinate as a positive integer."""
    if width <= 0 or pos.x < 0 or pos.y < 0:
        raise ValueError("invalid position or map width")
    return 1 + pos.y * width + pos.x


def unpack_position(value: int, width: int) -> Position | None:
    """Decode a position; zero means unknown."""
    if value == UNKNOWN:
        return None
    if value < 0 or width <= 0:
        raise ValueError("invalid packed position or map width")
    index = value - 1
    return Position(index % width, index // width)
