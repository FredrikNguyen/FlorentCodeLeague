"""Candidate bot package; must remain pure Python and self-contained."""
