"""Safe starter candidate.

This is deliberately a capability baseline, not a competitive final strategy.
"""

from __future__ import annotations

from fcode import Controller, Direction, EntityType, Environment

from .comms import SCHEMA_VERSION, Slot, pack_position, unpack_position
from .navigation import CARDINALS, move_toward_or_fallback


class Player:
    def __init__(self) -> None:
        self._cursor = 0
        self._error_count = 0

    def run(self, ct: Controller) -> None:
        try:
            self._run(ct)
        except Exception:
            # Preserve the unit. During development, inspect replay/console and tests.
            self._error_count += 1
            if self._error_count <= 3:
                try:
                    pos = ct.get_position()
                    ct.draw_indicator_dot(pos, 255, 0, 0)
                except Exception:
                    pass

    def _run(self, ct: Controller) -> None:
        entity_type = ct.get_entity_type()
        if entity_type == EntityType.CORE:
            self._run_core(ct)
        elif entity_type == EntityType.BUILDER_BOT:
            self._run_builder(ct)
        elif entity_type in (EntityType.GUNNER, EntityType.SENTINEL):
            self._run_firing_turret(ct)
        elif entity_type == EntityType.LAUNCHER:
            self._run_launcher(ct)

    def _run_core(self, ct: Controller) -> None:
        ct.write_store(int(Slot.SCHEMA_VERSION), SCHEMA_VERSION)

        desired_builders = 4
        ct.write_store(int(Slot.DESIRED_BUILDERS), desired_builders)
        # get_unit_count() includes the Core, so add one.
        if ct.get_unit_count() < desired_builders + 1:
            for pos in ct.get_nearby_tiles(dist_sq=2):
                if ct.can_spawn(pos):
                    ct.spawn_builder(pos)
                    return

    def _run_builder(self, ct: Controller) -> None:
        pos = ct.get_position()
        width = ct.get_map_width()

        # Build a visible adjacent first Harvester when legal.
        for direction in CARDINALS:
            target = pos.add(direction)
            if not self._in_bounds(ct, target):
                continue
            if ct.get_tile_env(target) == Environment.ORE_TITANIUM:
                if ct.can_build_harvester(target):
                    ct.build_harvester(target)
                    return

        # Publish one visible ore target. Multiple writers are tolerated only in this starter;
        # Milestone 2 must designate a single scout writer and add an epoch.
        for tile in ct.get_nearby_tiles():
            if ct.get_tile_env(tile) == Environment.ORE_TITANIUM:
                ct.write_store(int(Slot.PRIMARY_ORE), pack_position(tile, width))
                target = tile
                break
        else:
            target = unpack_position(ct.read_store(int(Slot.PRIMARY_ORE)), width)

        if target is not None:
            moved, self._cursor = move_toward_or_fallback(
                ct, target, cursor=self._cursor
            )
            if moved:
                return

        for offset in range(len(CARDINALS)):
            direction = CARDINALS[(self._cursor + offset) % len(CARDINALS)]
            if ct.can_move(direction):
                ct.move(direction)
                self._cursor = (self._cursor + offset + 1) % len(CARDINALS)
                return
        self._cursor = (self._cursor + 1) % len(CARDINALS)

    def _run_firing_turret(self, ct: Controller) -> None:
        for target in ct.get_attackable_tiles():
            if ct.can_fire(target):
                ct.fire(target)
                return

    def _run_launcher(self, ct: Controller) -> None:
        # Launcher policy is intentionally deferred until destination scoring exists.
        return

    @staticmethod
    def _in_bounds(ct: Controller, pos) -> bool:
        return 0 <= pos.x < ct.get_map_width() and 0 <= pos.y < ct.get_map_height()
