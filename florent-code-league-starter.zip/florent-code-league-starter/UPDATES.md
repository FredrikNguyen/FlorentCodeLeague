# Florent Code League development and live updates

This file is the durable handoff between Codex sessions. It is append-only except for the **Current state** table, which automation may refresh.

## Current state

| Field | Value |
|---|---|
| Workflow phase | `idle` |
| Working candidate | `bots/candidate` |
| Current active platform version | unknown |
| Last known-good platform version | unknown |
| Previous active platform version | unknown |
| Last known-good live score | unknown |
| Current candidate live score | unknown |
| Last deployment | never |
| Last observation | never |
| Last decision | none |

Machine-readable state: [`state/live_state.json`](state/live_state.json).

## Score definition

The primary live score is the mean fractional score over rated five-game series during a version's observation window:

```text
series score = our game wins / 5
live score   = mean(series score)
```

Also record rating delta and opponent-adjusted residual when available. Reliability failures override score and trigger immediate rollback.

## Append-only update log

<!-- Automation appends newest entries immediately below this comment. -->

### Session startup and scoped document routing added — 2026-08-05T00:25:00Z

- Added generated `docs/START_HERE.md` plus machine-readable `state/project_state.json` for cross-session development focus.
- Root `AGENTS.md` now requires a startup bootstrap but routes agents to detailed documents conditionally instead of loading everything every time.
- Added nested instructions for `bots/candidate/`, `scripts/`, and `tests/`.
- Updated Sol planner, Luna implementer, and Sol reviewer instructions to read startup state and nearest nested guidance.
- Added project-state/update scripts, automatic startup-summary refresh, Make targets, and regression tests.
- Resolved the orchestration-skill conflict: Luna implementation tasks cannot deploy, while the approved primary Sol/operator live workflow remains authorized by policy.


### Codex harness and live operator audited — 2026-08-05

- Found that the original custom-agent TOML did not prove Luna execution under the current Sol/Terra V2 versus Luna V1 mismatch.
- Added a reversible native-V1 route and an explicit process-isolated Sol → Luna Max → Sol fallback with exact command evidence.
- Added autonomous resumable upload, activation, live scoring, promotion, and rollback using `state/live_state.json`.
- Separated V1 and V2 configuration modes to avoid a boolean/table key conflict.
- Kept Sol as the only live reviewer/operator; Luna implements code but cannot modify live state or perform platform writes.


### Repository initialized — 2026-08-05

- Created the rules reference, Codex harness, starter bot, local/remote evaluation scripts, and submission workflow.
- Initial live state is unknown because no authenticated `fcode` session was available when the repository was generated.
