---
name: fcl-orchestration
description: Run the required Sol planner, Luna implementer, Sol reviewer workflow for Florent Code League changes.
---

# FCL orchestration

Use for any non-trivial bot or harness change.

1. Read `docs/START_HERE.md`, root `AGENTS.md`, both state JSON files, and relevant nested `AGENTS.md` files.
2. Spawn `sol_planner`; wait for a bounded implementation packet.
3. Validate the packet has objective, scope, non-goals, invariants, tests, evaluation, rollback, and done criteria.
4. Spawn one `luna_implementer` with the exact packet.
5. Run or inspect the requested tests.
6. Spawn `sol_reviewer` with the packet, diff, and evidence.
7. If approved, run the full applicable gate and summarize.
8. If changes are required, pass only the concrete remediation list to Luna, retest, and re-review.
9. Stop after two failed review loops.
10. Record the task/report/outcome in durable project state and refresh `docs/START_HERE.md`.

Implementation workers never perform platform writes. After a separately approved release gate, the primary Sol/operator may use the repository's already-authorized live workflow according to `configs/live_policy.toml`, `scripts/AGENTS.md`, and `docs/LIVE_AUTOPILOT.md`.

Parallelize only independent read-only exploration or review. Never let multiple workers edit coupled bot files simultaneously.
