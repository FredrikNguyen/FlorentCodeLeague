from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import tomllib

from common import ROOT, require_executable, save_json, utc_run_id
from update_log import append_update
from project_context import refresh_start_here, update_project_state

CONFIG = ROOT / "configs/codex_harness.toml"
RUNTIME = ROOT / "state/codex_runtime.json"


def run_logged(argv: list[str], *, output: Path, cwd: Path = ROOT) -> dict:
    output.parent.mkdir(parents=True, exist_ok=True)
    proc = subprocess.run(
        argv,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    output.write_text(proc.stdout, encoding="utf-8")
    output.with_suffix(output.suffix + ".stderr").write_text(proc.stderr, encoding="utf-8")
    return {
        "argv": argv,
        "returncode": proc.returncode,
        "stdout_path": str(output.relative_to(ROOT)),
        "stderr_path": str(output.with_suffix(output.suffix + '.stderr').relative_to(ROOT)),
    }


def model_args(model: str, effort: str, sandbox: str, last: Path, jsonl: Path) -> list[str]:
    return [
        "codex", "exec",
        "--model", model,
        "--sandbox", sandbox,
        "--config", f'model_reasoning_effort="{effort}"',
        "--json",
        "--output-last-message", str(last),
    ]


def native_v1_args(last: Path) -> list[str]:
    state = json.loads(RUNTIME.read_text(encoding="utf-8"))
    catalog = Path(state["catalog_path"])
    if not catalog.is_file():
        raise FileNotFoundError(catalog)
    return [
        "codex", "exec",
        "--model", "gpt-5.6-sol",
        "--sandbox", "workspace-write",
        "--config", 'model_reasoning_effort="medium"',
        "--config", f'model_catalog_json="{catalog}"',
        "--config", "features.multi_agent=true",
        "--config", "features.multi_agent_v2=false",
        "--json",
        "--output-last-message", str(last),
    ]


def native_prompt(task: str, report_dir: Path) -> str:
    return f"""Use the Florent Code League orchestration protocol for this task:

{task}

Mandatory sequence:
0. Read docs/START_HERE.md, both state JSON files, root AGENTS.md, and applicable nested AGENTS.md files.
1. Spawn the named project agent sol_planner and wait for its bounded packet.
2. Spawn the named project agent luna_implementer with that packet. Luna must be the only code writer.
3. Run the packet's checks and save evidence under {report_dir.relative_to(ROOT)}.
4. Spawn sol_reviewer against the actual diff and evidence.
5. If review says CHANGES_REQUIRED, send only the remediation packet to luna_implementer and review once more.
6. Final answer must state the exact spawned agent names and models and begin its verdict line with APPROVED or CHANGES_REQUIRED.
Never upload or activate from this implementation task.
"""


def process_fallback(task: str, report_dir: Path, cfg: dict) -> tuple[bool, list[dict], str]:
    models = cfg["models"]
    records: list[dict] = []

    plan = report_dir / "plan.md"
    plan_jsonl = report_dir / "planner.jsonl"
    planner_prompt = f"""You are the read-only Sol planner for this repository.
Read docs/START_HERE.md, AGENTS.md, UPDATES.md, state/project_state.json,
state/live_state.json, all applicable nested AGENTS.md files, and only the task-specific
detailed docs required by those instructions, plus relevant code and tests.
Create a bounded implementation packet for:

{task}

Include objective, evidence, hypothesis, exact allowed files/functions, non-goals,
invariants, ordered steps, exact tests, evaluation, rollback, and binary done criteria.
Do not edit files. Save no prose outside the final packet.
"""
    argv = model_args(models["planner"], models["planner_effort"], "read-only", plan, plan_jsonl)
    records.append(run_logged(argv + [planner_prompt], output=plan_jsonl))
    if records[-1]["returncode"] != 0 or not plan.exists():
        return False, records, "planner failed"

    impl = report_dir / "implementation.md"
    impl_jsonl = report_dir / "luna-implementer.jsonl"
    implement_prompt = f"""You are the explicit Luna implementation worker.
Your model was selected by the harness as {models['implementer']} with reasoning {models['implementer_effort']}.
Read docs/START_HERE.md, root and applicable nested AGENTS.md files, then read the
approved packet at {plan.relative_to(ROOT)} and implement exactly it.
Modify only allowed files. Run focused checks, save evidence beneath {report_dir.relative_to(ROOT)},
and return implemented changes, unchanged non-goals, commands/results, risks, and diff summary.
Never upload, activate, roll back, or edit UPDATES.md/live state.
"""
    argv = model_args(models["implementer"], models["implementer_effort"], "workspace-write", impl, impl_jsonl)
    records.append(run_logged(argv + [implement_prompt], output=impl_jsonl))
    if records[-1]["returncode"] != 0 or not impl.exists():
        return False, records, "Luna implementer failed"

    review = report_dir / "review-1.md"
    review_jsonl = report_dir / "sol-review-1.jsonl"
    review_prompt = f"""You are the read-only Sol reviewer.
Read docs/START_HERE.md, root and applicable nested AGENTS.md files, the implementation
packet at {plan.relative_to(ROOT)}, implementation evidence at
{impl.relative_to(ROOT)}, the actual git diff, current rules, and tests.
Return APPROVED or CHANGES_REQUIRED first. Blocking findings need priority, location,
consequence, evidence, correction, and retest. Do not edit files.
"""
    argv = model_args(models["reviewer"], models["reviewer_effort"], "read-only", review, review_jsonl)
    records.append(run_logged(argv + [review_prompt], output=review_jsonl))
    verdict = review.read_text(encoding="utf-8") if review.exists() else ""
    if records[-1]["returncode"] != 0:
        return False, records, "reviewer failed"
    if verdict.lstrip().startswith("APPROVED"):
        return True, records, "APPROVED"

    for loop in range(2, int(cfg.get("max_review_loops", 2)) + 1):
        remediation = report_dir / f"remediation-{loop}.md"
        remediation_jsonl = report_dir / f"luna-remediation-{loop}.jsonl"
        prompt = f"""You are the explicit Luna remediation worker ({models['implementer']}).
Read docs/START_HERE.md, applicable AGENTS.md files, the original packet at
{plan.relative_to(ROOT)} and findings at {review.relative_to(ROOT)}.
Correct only those findings, rerun exact retests, and report evidence. Do not broaden scope
or perform platform operations.
"""
        argv = model_args(models["implementer"], models["implementer_effort"], "workspace-write", remediation, remediation_jsonl)
        records.append(run_logged(argv + [prompt], output=remediation_jsonl))
        if records[-1]["returncode"] != 0:
            return False, records, "Luna remediation failed"

        next_review = report_dir / f"review-{loop}.md"
        next_jsonl = report_dir / f"sol-review-{loop}.jsonl"
        prompt = f"""You are the read-only Sol reviewer. Read docs/START_HERE.md and applicable AGENTS.md
files, then re-review the original packet
{plan.relative_to(ROOT)}, prior findings {review.relative_to(ROOT)}, remediation
{remediation.relative_to(ROOT)}, actual diff, and test evidence. Return APPROVED or
CHANGES_REQUIRED first. Do not edit files.
"""
        argv = model_args(models["reviewer"], models["reviewer_effort"], "read-only", next_review, next_jsonl)
        records.append(run_logged(argv + [prompt], output=next_jsonl))
        verdict = next_review.read_text(encoding="utf-8") if next_review.exists() else ""
        review = next_review
        if records[-1]["returncode"] != 0:
            return False, records, "re-review failed"
        if verdict.lstrip().startswith("APPROVED"):
            return True, records, "APPROVED"

    return False, records, "CHANGES_REQUIRED after maximum loops"


def main() -> int:
    parser = argparse.ArgumentParser(description="Verified Sol -> Luna -> Sol harness")
    parser.add_argument("task", nargs="+")
    parser.add_argument("--backend", choices=["auto", "native-v1", "process"], default="auto")
    args = parser.parse_args()
    require_executable("codex")
    refresh_start_here()
    task = " ".join(args.task).strip()
    cfg = tomllib.loads(CONFIG.read_text(encoding="utf-8"))
    report_dir = ROOT / "reports" / utc_run_id("codex")
    report_dir.mkdir(parents=True, exist_ok=True)
    records: list[dict] = []
    backend = None
    approved = False
    outcome = "not run"

    want_native = args.backend in {"auto", "native-v1"} and RUNTIME.exists()
    if want_native:
        backend = "native-v1"
        last = report_dir / "native-final.md"
        jsonl = report_dir / "native.jsonl"
        try:
            argv = native_v1_args(last)
            record = run_logged(argv + [native_prompt(task, report_dir)], output=jsonl)
            records.append(record)
            evidence = (jsonl.read_text(encoding="utf-8") + "\n" + (last.read_text(encoding="utf-8") if last.exists() else "")).lower()
            luna_evidence = "luna_implementer" in evidence and "gpt-5.6-luna" in evidence
            approved = record["returncode"] == 0 and luna_evidence and "approved" in evidence
            outcome = "APPROVED" if approved else "native V1 did not provide complete Luna/approval evidence"
        except Exception as exc:
            outcome = f"native V1 unavailable: {exc}"

    if not approved and args.backend != "native-v1" and cfg.get("allow_process_fallback", True):
        backend = "process-fallback"
        approved, fallback_records, outcome = process_fallback(task, report_dir, cfg)
        records.extend(fallback_records)

    manifest = {
        "schema_version": 1,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "task": task,
        "backend": backend,
        "approved": approved,
        "outcome": outcome,
        "required_models": cfg["models"],
        "luna_verified": any(
            "gpt-5.6-luna" in " ".join(record.get("argv", []))
            or "luna" in record.get("stdout_path", "").lower()
            for record in records
        ),
        "commands": records,
    }
    save_json(report_dir / "manifest.json", manifest)
    update_project_state(
        last_codex_task=task,
        last_codex_outcome=outcome,
        last_codex_report=str(report_dir.relative_to(ROOT)),
    )
    append_update(
        "Codex implementation task",
        [
            f"Task: {task}",
            f"Backend: {backend}",
            f"Luna evidence recorded: {manifest['luna_verified']}",
            f"Outcome: {outcome}",
            f"Report: {report_dir.relative_to(ROOT)}",
        ],
    )
    print(json.dumps(manifest, indent=2))
    return 0 if approved else 1


if __name__ == "__main__":
    raise SystemExit(main())
