# Tooling and live-operation instructions

These instructions apply to all files under `scripts/`.

## Required reading

Before changing general tooling, read:

- root `AGENTS.md`;
- `docs/START_HERE.md`;
- `docs/REPOSITORY_STRUCTURE.md`;
- the relevant tests under `tests/`.

Before changing or executing packaging, upload, activation, observation, promotion, or rollback behavior, also read:

- `docs/SUBMISSION_AND_VERSIONING.md`;
- `docs/LIVE_AUTOPILOT.md`;
- `configs/live_policy.toml`;
- `state/live_state.json` immediately before the operation.

Before changing the Codex harness, also read `docs/CODEX_HARNESS.md` and the latest Codex entries in `UPDATES.md`.

## Authority boundaries

- The user has authorized autonomous live operations when policy enables them.
- Only the primary Sol/operator process may perform platform writes.
- Luna may implement and test scripts but must never upload, activate, promote, roll back, or modify `state/live_state.json`/live deployment records.
- Ordinary implementation tasks must not accidentally trigger deployment.
- Do not delete old ready platform submissions.

## Durable-state requirements

- `state/live_state.json` is the machine source of truth for deployment and rollback.
- `state/project_state.json` is the machine source of truth for current development focus.
- `UPDATES.md` is append-only except for its generated current-state table.
- `docs/START_HERE.md` is generated from state; do not hand-edit it.
- Every state-changing script must write atomically enough to avoid a partially written JSON file.
- Refresh `docs/START_HERE.md` whenever project or live state changes.
- Preserve previous active and last known-good versions before activation.

## CLI and parsing discipline

- Prefer documented `--json` outputs, but retain raw stdout/stderr in `reports/`.
- Do not invent undocumented response fields; parse defensively and preserve unknown payloads.
- Set `FCODE_NO_UPDATE_CHECK=1` in automation.
- Never expose credentials or tokens in reports, logs, commits, or prompts.
- Platform-changing scripts must be explicit about the version/path they act on and record a report directory.
- Cross-session workflows must be resumable and idempotent where practical.

## Testing

- Unit tests must mock `fcode` and `codex`; tests must never use a real account or perform network/platform writes.
- Test refusal/guard paths as well as success paths.
- Test rollback-target preservation and state transitions.
- Run `make static` after tooling changes and add focused tests for new state fields or commands.
