from __future__ import annotations

import ast
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
CANDIDATE = ROOT / "bots/candidate"
FORBIDDEN_SUFFIXES = {".so", ".dll", ".dylib", ".pyd"}


class StaticContractTest(unittest.TestCase):
    def test_entrypoint_exists_and_mentions_player(self) -> None:
        entry = CANDIDATE / "main.py"
        self.assertTrue(entry.is_file())
        tree = ast.parse(entry.read_text(encoding="utf-8"))
        names = {
            alias.asname or alias.name
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom)
            for alias in node.names
        }
        classes = {
            node.name for node in ast.walk(tree) if isinstance(node, ast.ClassDef)
        }
        self.assertIn("Player", names | classes)

    def test_all_python_parses(self) -> None:
        for path in CANDIDATE.rglob("*.py"):
            with self.subTest(path=path):
                ast.parse(path.read_text(encoding="utf-8"))

    def test_no_native_extensions(self) -> None:
        bad = [
            p for p in CANDIDATE.rglob("*")
            if p.is_file() and p.suffix.lower() in FORBIDDEN_SUFFIXES
        ]
        self.assertEqual([], bad)

    def test_submission_limits(self) -> None:
        entries = [p for p in CANDIDATE.rglob("*") if p.is_file()]
        self.assertLessEqual(len(entries), 500)
        self.assertLessEqual(sum(p.stat().st_size for p in entries), 50 * 1024 * 1024)

    def test_no_direction_to_in_candidate_movement_helper(self) -> None:
        # Prevent the known tutorial trap; cardinal_direction_to is allowed.
        offenders = []
        for path in CANDIDATE.rglob("*.py"):
            text = path.read_text(encoding="utf-8")
            stripped = text.replace("cardinal_direction_to", "")
            if ".direction_to(" in stripped:
                offenders.append(str(path.relative_to(ROOT)))
        self.assertEqual([], offenders)


if __name__ == "__main__":
    unittest.main()
