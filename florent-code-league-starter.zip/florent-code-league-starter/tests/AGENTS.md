# Test instructions

These instructions apply to all files under `tests/`.

## Required reading

Read root `AGENTS.md`, `docs/START_HERE.md`, and the nearest production-file instructions before adding or changing tests.

## Test properties

- Tests must be deterministic and independent of execution order.
- Never require real Florent or Codex authentication.
- Never upload, activate, promote, roll back, or call a real network service.
- Mock subprocesses and use temporary directories for state-changing workflows.
- Assert behavior and invariants, not incidental formatting, unless the formatting is itself a durable protocol.
- Add regression tests for every discovered illegal-action, state-corruption, deployment, or startup-context bug.
- Keep tests fast enough for `make static` on every change.

## Required coverage areas

- Candidate packaging and `Player` entry-point contract.
- Explicit Luna model selection and harness evidence.
- Session bootstrap files and nested `AGENTS.md` discovery contract.
- Project/live state persistence and `docs/START_HERE.md` regeneration.
- Upload/activation separation, rollback target preservation, and no unauthorized Luna platform writes.
- Deterministic evaluation configuration and `--tle 10` enforcement.
