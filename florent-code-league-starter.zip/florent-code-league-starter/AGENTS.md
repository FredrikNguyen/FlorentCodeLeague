# AGENTS.md

## Mission

Build the strongest reliable Florent Code League bot through small, measurable, reversible experiments. Preserve a known-good platform version and automatically roll back live regressions.

## Mandatory session bootstrap

At the beginning of every new Codex session, before planning, editing, evaluating, or performing a platform action:

1. Read `docs/START_HERE.md` for the current milestone, hypothesis, next task, recent Codex result, and live deployment snapshot.
2. Read `UPDATES.md` for the current-state table and newest relevant change/deployment entries.
3. Read both machine-readable state files:
   - `state/project_state.json`
   - `state/live_state.json`
4. Run `git status --short` and inspect the current branch plus any relevant uncommitted diff. Never assume a prior chat reflects the current working tree.
5. Locate and obey the nearest applicable `AGENTS.md` for every file being changed. A nested file supplements or overrides this root guidance for its subtree.
6. If `docs/START_HERE.md` is missing or visibly stale relative to either state file, run `make refresh-start` before continuing.

Do **not** read every long document on every startup. Load the task-specific documents below before making decisions in that area.

## Task-specific required reading

### Bot mechanics or strategy

Before changing anything under `bots/candidate/`, or reasoning about movement, sensing, economy, logistics, combat, communication, maps, or game strategy:

- read `bots/candidate/AGENTS.md`;
- read `GAME_RULES.md`;
- read the relevant milestone in `docs/IMPLEMENTATION_PLAN.md`;
- read the latest rules/changelog warnings in `UPDATES.md`.

### Planning or implementation

Before a non-trivial code change:

- read `docs/CODEX_HARNESS.md`;
- follow the verified Sol → Luna → Sol workflow;
- read the current experiment record when one exists;
- require run evidence that Luna was actually invoked.

### Evaluation or promotion decisions

Before changing evaluation code or deciding whether a candidate is stronger:

- read `docs/EVALUATION_PLAN.md`;
- read the candidate experiment record;
- compare against `bots/baseline/` and the last known-good live version;
- inspect the nearest `AGENTS.md` for the files being changed.

### Packaging, upload, activation, live observation, promotion, or rollback

Immediately before any platform operation:

- read `scripts/AGENTS.md`;
- read `docs/SUBMISSION_AND_VERSIONING.md`;
- read `docs/LIVE_AUTOPILOT.md`;
- reread `state/live_state.json` after all preceding tests finish;
- verify that no newer candidate is already in `uploaded_processing` or `active_observing` unless policy explicitly permits it.

### Repository structure or project-wide tooling

Before reorganizing files, adding major modules, or changing cross-session state:

- read `docs/REPOSITORY_STRUCTURE.md`;
- read `docs/PROJECT_CONSIDERATIONS.md`;
- update `state/project_state.json` through `scripts/set_project_state.py` when the current milestone, hypothesis, experiment, or next task changes;
- run `make refresh-start` after changing project or live state.

## Reading and context discipline

- `docs/START_HERE.md` is a generated concise handoff, not the authoritative store.
- `state/project_state.json` is authoritative for current development focus.
- `state/live_state.json` is authoritative for deployment and rollback state.
- `UPDATES.md` is the human-readable append-only history.
- Do not hand-edit generated fields in `docs/START_HERE.md`; update the state files and regenerate it.
- Read only relevant sections of large documents, but never skip a required source because an old chat summarized it.
- When sources disagree, resolve the discrepancy before editing or deploying.
- At the end of an approved task, update the durable project state and regenerate `docs/START_HERE.md` so the next session can continue without chat history.

## Sources of truth

For game mechanics:

1. current behavior from a minimal engine test;
2. latest official changelog;
3. current API/rule references;
4. tutorial prose;
5. tutorial snippets and local notes.

For current Codex behavior:

1. an actual harness verification report;
2. the installed `codex --version` and `codex debug models` output;
3. current official Codex docs;
4. Reddit/GitHub bug reports.

## Required implementation workflow

Run non-trivial changes through `python scripts/codex_task.py "<task>"` or the equivalent Make target.

The harness must produce evidence for one of these backends:

- **native-v1:** Sol uses Codex `spawn_agent` to invoke the project `luna_implementer` after a reversible model-catalog V1 override;
- **process fallback:** separate `codex exec` worker sessions explicitly select Sol → Luna → Sol. This is not native `spawn_agent`, but it guarantees the implementer process is actually `gpt-5.6-luna` rather than silently inheriting Sol.

Never claim Luna was used merely because `.codex/agents/luna-implementer.toml` exists. A completed task must have `reports/codex-*/manifest.json` showing the backend, exact model invocations, exit codes, and Luna evidence.

Workflow:

1. Sol creates a bounded implementation packet.
2. Luna implements exactly that packet.
3. Required checks run and evidence is saved.
4. Sol reviews the actual diff and evidence.
5. On `CHANGES_REQUIRED`, Luna receives only the remediation packet.
6. Stop after two failed review loops and document the blocker.
7. Append the implemented change, tests, agent backend, and review verdict to `UPDATES.md`.
8. Update `state/project_state.json` with the latest task/report/outcome and run `make refresh-start`.

Parallelize only independent read-heavy analysis. Do not let multiple workers edit coupled bot files.

## Game-code invariants

- Submission entry point is `main.py` and exports `Player`.
- Pure Python compatible with the current competition sandbox.
- Route by `ct.get_entity_type()`; every unit has persistent per-instance state.
- Gate every action with the matching `can_*` method.
- Builder movement is cardinal only; use `cardinal_direction_to`.
- Build, attack, heal, and destroy target orthogonally adjacent tiles.
- A Builder cannot move and act in the same round.
- An exception escaping `run()` permanently destroys the unit.
- Query dynamic costs through `ct.get_*_cost()`.
- Global Store has 16 non-negative integer slots, delayed writes, and named ownership.
- Target local p99 CPU below 8 ms with `--tle 10`.
- Preserve deterministic behavior for fixed seeds unless an experiment explicitly tests randomness.

## Change discipline

- One hypothesis per candidate.
- Never edit `bots/baseline/` during an experiment.
- Never overwrite `bots/versions/` snapshots.
- Record parent, hypothesis, git SHA, tests, metrics, and result.
- A code change is incomplete without tests, evaluation evidence, Sol review, an `UPDATES.md` entry, and refreshed startup state.

## Autonomous platform operations

The user has explicitly authorized autonomous upload, activation, observation, and rollback when `configs/live_policy.toml` has `autonomous_live_ops = true`.

Only the primary Sol/operator may perform platform writes. Luna never uploads, activates, promotes, rolls back, or edits live state.

After a candidate passes the full applicable gate and Sol returns `APPROVED`:

1. append the implementation summary to `UPDATES.md`;
2. run `python scripts/release_candidate.py --slug <slug>` (or `make release-live SLUG=<slug>`), which packages an immutable version and deploys it;
3. preserve the previous active version as the rollback target;
4. let deployment state persist in `state/live_state.json` if processing continues beyond the session;
5. in a later session, run `python scripts/live_autopilot.py` or `make live-autopilot`;
6. append observed series score, adjusted score, rating/rank movement, match IDs, and decision;
7. automatically reactivate the last known-good version when the live policy says the candidate is worse or a reliability failure appears;
8. promote a successful candidate with `live_operator.py promote` and update the frozen local baseline separately.

Never deploy another candidate while the state is `active_observing` unless policy explicitly allows it. Never delete old ready submissions.

## Required checks

```bash
make codex-doctor
make static
make smoke
make eval-regression
make eval-local
make remote-gate
make package SLUG=<slug>
```

Before or after live operations:

```bash
make refresh-start
make live-bootstrap
make live-status
make live-autopilot
```

## Review priorities

1. Illegal action or escaping exception.
2. CPU/TLE and unbounded work.
3. Incorrect current mechanics.
4. State deadlocks and stale Store data.
5. Economy/logistics throughput regression.
6. Combat and ammo starvation.
7. Map/side/seed overfit.
8. Invalid evaluation or missing evidence.
9. Packaging/live-state/rollback correctness.
10. Startup-state/documentation drift.
11. Style only where it hides correctness.

A review verdict begins exactly `APPROVED` or `CHANGES_REQUIRED`.
