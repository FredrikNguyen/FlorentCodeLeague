# Verified Codex Sol/Luna harness

## Cross-session startup context

Every primary session and every custom worker must begin from repository state rather than chat history:

1. `docs/START_HERE.md`
2. `UPDATES.md`
3. `state/project_state.json`
4. `state/live_state.json`
5. root and nearest nested `AGENTS.md`
6. task-specific detailed documents

`docs/START_HERE.md` is generated and concise. `state/project_state.json` stores the current milestone, hypothesis, experiment, next task, and recent Codex report. Approved harness runs update the recent task/report/outcome automatically. Live-state changes refresh the same startup summary.

Do not load every large document into every worker. Sol's implementation packet must identify the exact detailed sections Luna and the reviewer need.

## Audit result

The original repository declared a `luna_implementer` custom agent, but that declaration was not proof that Luna actually ran. Current Codex deployments have had a backend mismatch where Sol/Terra route through multi-agent V2 while Luna remains on V1. In affected builds, Luna may be filtered out as an unknown model or a child may silently inherit an available parent model.

The revised harness never accepts configuration intent as execution evidence.

## Current custom-agent layout

Current Codex documentation loads project custom agents directly from standalone `.codex/agents/*.toml` files. The root `.codex/config.toml` therefore contains only supported global `[agents]` defaults; it does not use legacy per-agent registration tables. The agent `name` inside each file is the source of truth.

## Two verified routes

### Preferred: native V1 custom-agent route

1. `python scripts/codex_luna_doctor.py` inspects the installed model catalog.
2. `python scripts/setup_codex_v1_catalog.py` creates a complete copy of the current catalog and changes only Sol, Terra, and Luna `multi_agent_version` fields to `v1`.
3. The original catalog is backed up under `$CODEX_HOME/fcl-harness/`.
4. No global `config.toml` is modified.
5. `scripts/codex_v1.sh` or `codex_task.py` passes the catalog explicitly for that invocation.
6. The task is accepted only when logs contain both the named `luna_implementer` and `gpt-5.6-luna` plus an approval verdict.

This is a reversible community workaround for the current catalog mismatch, not an official stability guarantee.

### Guaranteed model fallback: process-isolated workers

If native V1 is unavailable or cannot prove the Luna spawn, `codex_task.py` runs separate non-interactive sessions:

```text
Sol medium, read-only planner
    → Luna max, workspace-write implementer
    → Sol medium, read-only reviewer
    → optional Luna remediation + Sol re-review
```

Each `codex exec` command includes an explicit `--model` and reasoning override. The manifest records exact argv, exit code, stdout/stderr artifacts, backend, and whether Luna evidence exists. This route is not a native subagent spawn, but it cannot silently turn the implementer into Sol without contradicting the recorded command and Codex response.

## Usage

```bash
make codex-doctor
make setup-codex-v1
make verify-luna TASK="Implement milestone 2.1"
```

Or:

```bash
python scripts/codex_task.py --backend process "Implement milestone 2.1"
```

Reports live under `reports/codex-*/manifest.json`. Every completed task appends a durable entry to `UPDATES.md`.

## Optional V2 visibility diagnostic

Do not combine a `[features.multi_agent_v2]` table with the V1 boolean override in one project config; TOML/config merging can treat that as a type conflict. The project config therefore stays neutral. `scripts/codex_v2_visible.sh` enables the reported V2 metadata workaround only for a separate diagnostic invocation. It improves routing visibility but does not solve the backend-version filter.

## Review boundary

Luna writes implementation code only. Sol plans, reviews, and operates live deployment. Luna may not upload, activate, roll back, or edit durable live state.
