# Install the ChatGPT planning-command repair

Run from the FlorentCodeLeague repository root:

```bash
unzip -o /path/to/fcl-chatgpt-plan-fix.zip -d /tmp/fcl-plan-fix
cp /tmp/fcl-plan-fix/fcl-chatgpt-plan-fix/scripts/set_planning_request.py scripts/
cp /tmp/fcl-plan-fix/fcl-chatgpt-plan-fix/scripts/build_chatgpt_bundle.py scripts/
mkdir -p docs
cp -n /tmp/fcl-plan-fix/fcl-chatgpt-plan-fix/docs/PLANNING_REQUEST.md docs/
```

Ensure the Makefile contains:

```make
chatgpt-plan:
\t@test -n "$(REQUEST)" || (echo 'Usage: make chatgpt-plan REQUEST="..."' && exit 2)
\t$(PYTHON) scripts/set_planning_request.py "$(REQUEST)"
\t$(PYTHON) scripts/build_chatgpt_bundle.py
```

Then run:

```bash
make chatgpt-plan REQUEST="Plan the next best move for improving the bot"
```
